from __future__ import absolute_import
import tensorflow as tf
import math as m
import numpy as np
from keras import activations, initializers, regularizers, constraints
from keras import backend as K
from keras.layers import Layer, LeakyReLU, Dropout, AveragePooling2D, AveragePooling1D, MaxPooling2D, Concatenate
from keras import Input, Model
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.layers import Dense, Flatten
from keras.optimizers import Adam
from keras.regularizers import l2
from keras.initializers import RandomUniform
from keras.constraints import max_norm, non_neg, unit_norm, min_max_norm
import scipy.sparse as sp
from ops import sp_matrix_to_sp_tensor, transpose, mixed_mode_dot, filter_dot

_LAYER_UIDS = {}
def get_layer_uid(layer_name=''):
    """Helper function, assigns unique layer IDs."""
    if layer_name not in _LAYER_UIDS:
        _LAYER_UIDS[layer_name] = 1
        return 1
    else:
        _LAYER_UIDS[layer_name] += 1
        return _LAYER_UIDS[layer_name]

class Exponentialtransformation(Layer):

    def __init__(self,
                 channels,
                 activation=None,
                 initial_kernel=None,
                 deep_kernel=None,
                 kernel_initializer='glorot_uniform',
                 kernel_regularizer=None,
                 activity_regularizer=None,
                 kernel_constraint=None,
                 **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(Exponentialtransformation, self).__init__(**kwargs)
        self.initial_kernel = initial_kernel
        self.deep_kernel = deep_kernel
        self.channels = channels
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.kernel_regularizer = regularizers.get(kernel_regularizer)
        self.activity_regularizer = regularizers.get(activity_regularizer)
        self.kernel_constraint = constraints.get(kernel_constraint)
        self.supports_masking = False

    def build(self, input_shape):
        assert input_shape[-1] >= 1
        self.kernel_mu0 = self.add_weight(shape=(1,),
                                      initializer=self.kernel_initializer,
                                      name='mu0_kernel',
                                      regularizer=self.kernel_regularizer,
                                      constraint=self.kernel_constraint)

        self.kernel_mu1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='mu1_kernel',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)

        self.kernel_sigma0 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='sigma0_kernel',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)

        self.kernel_sigma1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='sigma1_kernel',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)

        if self.initial_kernel:
            self.initial_kernel = self.add_weight(shape=(1, self.channels),
                                                  initializer=self.kernel_initializer,
                                                  name='initial_weight_kernel',
                                                  regularizer=self.kernel_regularizer,
                                                  constraint=self.kernel_constraint)
        else:
            self.initial_kernel = None

        if self.deep_kernel:
            self.deep_kernel = self.add_weight(shape=(input_shape[-2], self.channels),
                                                  initializer=self.kernel_initializer,
                                                  name='deep_weight_kernel',
                                                  regularizer=self.kernel_regularizer,
                                                  constraint=self.kernel_constraint)
        else:
            self.deep_kernel = None

        self.nu = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0., maxval=0.9),
                                             name='nu_kernel',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0.09, max_value=1))
        self.p = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0., maxval=5.),
                                             name='p_kernel',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0., max_value=5.))

        self.built = True

    def call(self, inputs):

        if inputs.shape[-1] == 2:
            temp1 = (inputs[:, :, :1] - self.kernel_mu0)
            temp1 = tf.pow(tf.multiply(tf.pow(temp1,2), tf.pow(self.kernel_sigma0, 2)),self.p)

            const = tf.constant(1., dtype=tf.float32)
            new_death_col = tf.where(tf.less(inputs[:, :, 1:], nu),
                                     tf.multiply(tf.log(tf.divide(inputs[:, :, 1:], nu)),nu)+nu,
                                     tf.multiply(inputs[:, :, 1:], const))

            temp2 = (new_death_col - self.kernel_mu1)
            temp2 = tf.pow(tf.multiply(tf.pow(temp2,2), tf.pow(self.kernel_sigma1, 2)),self.p)
            output = tf.exp(-temp1 - temp2)

            output = K.dot(output, self.initial_kernel)
            output = tf.nn.elu(output)
            output = K.expand_dims(output, axis=- 1)
        else:
            inputs = K.squeeze(inputs, axis=-1)
            output = K.dot(inputs, self.deep_kernel)
            output = tf.nn.elu(output)
            output = K.expand_dims(output, axis=- 1)

        return output

    def compute_output_shape(self, input_shape):
        if input_shape[-1] == 2:
            output_shape = input_shape[:-1] + (self.channels,) + (1,)
        else:
            output_shape = input_shape[:-2] + (self.channels,) + (1,)
        return output_shape

    def get_config(self):
        config = {
            'initial_kernel': self.initial_kernel,
            'deep_kernel': self.deep_kernel,
            'channels': self.channels,
            'activation': activations.serialize(self.activation),
            'kernel_initializer': initializers.serialize(self.kernel_initializer),
            'kernel_regularizer': regularizers.serialize(self.kernel_regularizer),
            'activity_regularizer': regularizers.serialize(self.activity_regularizer),
            'kernel_constraint': constraints.serialize(self.kernel_constraint),
        }
        base_config = super(Exponentialtransformation, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


# for multiple inputs #
class nOCTExponentialtransformation(Layer):

    def __init__(self,
                 channels,
                 activation=None,
                 initial_kernel=None,
                 deep_kernel=None,
                 regular_stretched=None,
                 kernel_initializer='glorot_uniform',
                 kernel_regularizer=None,
                 activity_regularizer=None,
                 kernel_constraint=None,
                 **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(nOCTExponentialtransformation, self).__init__(**kwargs)
        self.initial_kernel = initial_kernel
        self.deep_kernel = deep_kernel
        self.channels = channels
        self.regular_stretched = regular_stretched,
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.kernel_regularizer = regularizers.get(kernel_regularizer)
        self.activity_regularizer = regularizers.get(activity_regularizer)
        self.kernel_constraint = constraints.get(kernel_constraint)
        self.supports_masking = False

    def build(self, input_shape):
        self.kernel_mu0 = self.add_weight(shape=(1,),
                                      initializer=self.kernel_initializer,
                                      name='mu0_kernel',
                                      regularizer=self.kernel_regularizer,
                                      constraint=self.kernel_constraint)
        self.kernel_mu0_1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='mu0_kernel_1',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)
        self.kernel_mu0_2 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu0_kernel_2',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)

        self.kernel_mu1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='mu1_kernel',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)
        self.kernel_mu1_1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='mu1_kernel_1',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)
        self.kernel_mu1_2 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu1_kernel_2',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)

        self.kernel_sigma0 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='sigma0_kernel',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)
        self.kernel_sigma0_1 = self.add_weight(shape=(1,),
                                             initializer=self.kernel_initializer,
                                             name='sigma0_kernel_1',
                                             regularizer=self.kernel_regularizer,
                                             constraint=self.kernel_constraint)
        self.kernel_sigma0_2 = self.add_weight(shape=(1,),
                                               initializer=self.kernel_initializer,
                                               name='sigma0_kernel_2',
                                               regularizer=self.kernel_regularizer,
                                               constraint=self.kernel_constraint)

        self.kernel_sigma1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='sigma1_kernel',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)

        self.kernel_sigma1_1 = self.add_weight(shape=(1,),
                                             initializer=self.kernel_initializer,
                                             name='sigma1_kernel_1',
                                             regularizer=self.kernel_regularizer,
                                             constraint=self.kernel_constraint)
        self.kernel_sigma1_2 = self.add_weight(shape=(1,),
                                               initializer=self.kernel_initializer,
                                               name='sigma1_kernel_2',
                                               regularizer=self.kernel_regularizer,
                                               constraint=self.kernel_constraint)

        if self.initial_kernel:
            self.initial_kernel_1 = self.add_weight(shape=(1, self.channels),
                                                  initializer=self.kernel_initializer,
                                                  name='initial_weight_kernel',
                                                  regularizer=self.kernel_regularizer,
                                                  constraint=self.kernel_constraint)
            self.initial_kernel_2 = self.add_weight(shape=(1, self.channels),
                                                    initializer=self.kernel_initializer,
                                                    name='initial_weight_kernel_1',
                                                    regularizer=self.kernel_regularizer,
                                                    constraint=self.kernel_constraint)
            self.initial_kernel_3 = self.add_weight(shape=(1, self.channels),
                                                    initializer=self.kernel_initializer,
                                                    name='initial_weight_kernel_2',
                                                    regularizer=self.kernel_regularizer,
                                                    constraint=self.kernel_constraint)
        else:
            self.initial_kernel = None

        if self.deep_kernel:
            self.deep_kernel = self.add_weight(shape=(input_shape[-2], self.channels),
                                                   initializer=self.kernel_initializer,
                                                   name='deep_weight_kernel',
                                                   regularizer=self.kernel_regularizer,
                                                   constraint=self.kernel_constraint)
        else:
            self.deep_kernel = None

        self.nu = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0., maxval=0.9),
                                             name='nu_kernel',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0.09, max_value=1))
        self.nu_1 = self.add_weight(shape=(1,),
                                  initializer=RandomUniform(minval=0., maxval=0.9),
                                  name='nu_kernel_1',
                                  regularizer=self.kernel_regularizer,
                                  constraint=min_max_norm(min_value=0.09, max_value=1))
        self.nu_2 = self.add_weight(shape=(1,),
                                    initializer=RandomUniform(minval=0., maxval=0.9),
                                    name='nu_kernel_2',
                                    regularizer=self.kernel_regularizer,
                                    constraint=min_max_norm(min_value=0.09, max_value=1))


        self.built = True

    def call(self, inputs):
        if inputs[0].shape[-1] == 2:

            # low t #
            temp1_1 = (inputs[0][:, :, :1] - self.kernel_mu0)
            temp1_1 = tf.pow(tf.multiply(tf.pow(temp1_1,2), tf.pow(self.kernel_sigma0, 2)),2) # can replace 2 with self.p #

            nu_1 = self.nu
            const = tf.constant(1., dtype=tf.float32)

            if self.regular_stretched:
                new_death_col_1 = tf.where(tf.less(inputs[0][:, :, 1:], nu_1),
                                           1.5 * nu_1 - 0.5 * tf.divide(nu_1 ** 3, inputs[1][:, :, 1:]),
                                           tf.multiply(inputs[0][:, :, 1:], const))
            else:
                new_death_col_1 = tf.where(tf.less(inputs[0][:, :, 1:], nu_1),
                                           tf.multiply(tf.math.log(tf.divide(inputs[0][:, :, 1:], nu_1)), nu_1) + nu_1,
                                           tf.multiply(inputs[0][:, :, 1:], const))

            temp2_1 = (new_death_col_1 - self.kernel_mu1)
            temp2_1 = tf.pow(tf.multiply(tf.pow(temp2_1,2), tf.pow(self.kernel_sigma1, 2)),2) # can replace 2 with self.p #

            output_1 = tf.exp(-temp1_1 - temp2_1)
            output_1 = K.dot(output_1, self.initial_kernel_1)

            # -------------------------------------------------------------#
            # median t #
            temp1_2 = (inputs[1][:, :, :1] - self.kernel_mu0_1)
            temp1_2 = tf.pow(tf.multiply(tf.pow(temp1_2, 2), tf.pow(self.kernel_sigma0_1, 2)),2)  # can replace 2 with self.p #

            nu_2 = self.nu_1
            const_2 = tf.constant(1., dtype=tf.float32)

            if self.regular_stretched:
                new_death_col_2 = tf.where(tf.less(inputs[1][:, :, 1:], nu_2),
                                           1.5 * nu_2 - 0.5 * tf.divide(nu_2 ** 3, inputs[1][:, :, 1:]),
                                           tf.multiply(inputs[1][:, :, 1:], const_2))
            else:
                new_death_col_2 = tf.where(tf.less(inputs[1][:, :, 1:], nu_2),
                                           tf.multiply(tf.math.log(tf.divide(inputs[1][:, :, 1:], nu_2)), nu_2) + nu_2,
                                           tf.multiply(inputs[1][:, :, 1:], const_2))

            temp2_2 = (new_death_col_2 - self.kernel_mu1_1)
            temp2_2 = tf.pow(tf.multiply(tf.pow(temp2_2, 2), tf.pow(self.kernel_sigma1_1, 2)), 2)  # can replace 2 with self.p #

            output_2 = tf.exp(-temp1_2 - temp2_2)
            output_2 = K.dot(output_2, self.initial_kernel_2)

            # -------------------------------------------------------------#
            # high t #
            temp1_3 = (inputs[2][:, :, :1] - self.kernel_mu0_2)
            temp1_3 = tf.pow(tf.multiply(tf.pow(temp1_3, 2), tf.pow(self.kernel_sigma0_2, 2)), 2)  # can replace 2 with self.p #

            nu_3 = self.nu_2
            const_3 = tf.constant(1., dtype=tf.float32)

            if self.regular_stretched:
                new_death_col_3 = tf.where(tf.less(inputs[2][:, :, 1:], nu_3),
                                           1.5 * nu_3 - 0.5 * tf.divide(nu_3 ** 3, inputs[2][:, :, 1:]),
                                           tf.multiply(inputs[1][:, :, 1:], const_3))
            else:
                new_death_col_3 = tf.where(tf.less(inputs[2][:, :, 1:], nu_3),
                                           tf.multiply(tf.math.log(tf.divide(inputs[2][:, :, 1:], nu_3)), nu_3) + nu_3,
                                           tf.multiply(inputs[2][:, :, 1:], const_3))

            temp2_3 = (new_death_col_3 - self.kernel_mu1_2)
            temp2_3 = tf.pow(tf.multiply(tf.pow(temp2_3, 2), tf.pow(self.kernel_sigma1_2, 2)), 2) # can replace 2 with self.p #

            output_3 = tf.exp(-temp1_3 - temp2_3)
            output_3 = K.dot(output_3, self.initial_kernel_3)

            # this line is for kernel #
            output = tf.concat([output_1, output_2, output_3], axis= -1)
            output = K.expand_dims(output, axis= -1)
            output = MaxPooling2D(pool_size=(1, 3), padding='same')(output)
            output = tf.nn.elu(output)

        else:
            inputs = K.squeeze(inputs, axis=-1)
            output = K.dot(inputs, self.deep_kernel)
            output = tf.nn.elu(output) # elu is optimal
            output = K.expand_dims(output, axis=-1)

        return output

    def compute_output_shape(self, input_shape):
        if len(input_shape) == 3:
            output_shape = input_shape[0][:-1] + (self.channels,) + (1,)
        else:
            output_shape = input_shape[:-2] + (self.channels,) + (1,)
        return output_shape

    def get_config(self):
        config = {
            'initial_kernel': self.initial_kernel,
            'deep_kernel': self.deep_kernel,
            'channels': self.channels,
            'regular_stretched': self.regular_stretched,
            'activation': activations.serialize(self.activation),
            'kernel_initializer': initializers.serialize(self.kernel_initializer),
            'kernel_regularizer': regularizers.serialize(self.kernel_regularizer),
            'activity_regularizer': regularizers.serialize(self.activity_regularizer),
            'kernel_constraint': constraints.serialize(self.kernel_constraint),
        }
        base_config = super(nOCTExponentialtransformation, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


# for combination #
class Comb_convolution(Layer):
    
    def __init__(self,
                 channels,
                 activation=None,
                 kernel_initializer='glorot_uniform',
                 kernel_regularizer=None,
                 activity_regularizer=None,
                 kernel_constraint=None,
                 **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(Comb_convolution, self).__init__(**kwargs)
        self.channels = channels
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.kernel_regularizer = regularizers.get(kernel_regularizer)
        self.activity_regularizer = regularizers.get(activity_regularizer)
        self.kernel_constraint = constraints.get(kernel_constraint)
        self.supports_masking = False
    
    def build(self, input_shape):
        assert len(input_shape) == 2
        self.kernel = self.add_weight(shape=(input_shape[1][1],self.channels),
                                      initializer=self.kernel_initializer,
                                      name='comb_kernel',
                                      regularizer=self.kernel_regularizer,
                                      constraint=self.kernel_constraint)
                                      
                                      
        self.built = True
    
    def call(self, inputs):
        pd_input = inputs[0]
        pointnet_input = inputs[1]

        output = tf.einsum('ijk, xyz -> ijz', pd_input, pointnet_input)
        output = K.dot(output, self.kernel)
        output = tf.nn.elu(output)
        return output
    
    def compute_output_shape(self, input_shape):
        output_shape = input_shape[0][:-1] + (self.channels,)
        return output_shape
    
    def get_config(self):
        config = {
            'channels': self.channels,
            'activation': activations.serialize(self.activation),
            'kernel_initializer': initializers.serialize(self.kernel_initializer),
            'kernel_regularizer': regularizers.serialize(self.kernel_regularizer),
            'activity_regularizer': regularizers.serialize(self.activity_regularizer),
            'kernel_constraint': constraints.serialize(self.kernel_constraint),
        }
        base_config = super(Comb_convolution, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


# for periodic kernel #
class nOCTPERIODIC(Layer):

    def __init__(self,
                 channels,
                 activation=None,
                 initial_kernel=None,
                 kernel_initializer='glorot_uniform',
                 kernel_regularizer=None,
                 activity_regularizer=None,
                 kernel_constraint=None,
                 **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(nOCTPERIODIC, self).__init__(**kwargs)
        self.initial_kernel = initial_kernel
        self.channels = channels
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.kernel_regularizer = regularizers.get(kernel_regularizer)
        self.activity_regularizer = regularizers.get(activity_regularizer)
        self.kernel_constraint = constraints.get(kernel_constraint)
        self.supports_masking = False

    def build(self, input_shape):
        self.kernel_mu0_1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='mu0_kernel_1',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)
        self.kernel_mu0_2 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu0_kernel_2',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)
        self.kernel_mu0_3 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu0_kernel_3',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)
        self.kernel_mu0_4 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu0_kernel_4',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)

        self.kernel_mu1_1 = self.add_weight(shape=(1,),
                                          initializer=self.kernel_initializer,
                                          name='mu1_kernel_1',
                                          regularizer=self.kernel_regularizer,
                                          constraint=self.kernel_constraint)
        self.kernel_mu1_2 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu1_kernel_2',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)
        self.kernel_mu1_3 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu1_kernel_3',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)
        self.kernel_mu1_4 = self.add_weight(shape=(1,),
                                            initializer=self.kernel_initializer,
                                            name='mu1_kernel_4',
                                            regularizer=self.kernel_regularizer,
                                            constraint=self.kernel_constraint)

        if self.initial_kernel:
            self.initial_kernel_1 = self.add_weight(shape=(1, self.channels),
                                                    initializer=self.kernel_initializer,
                                                    name='initial_weight_kernel_1',
                                                    regularizer=self.kernel_regularizer,
                                                    constraint=self.kernel_constraint)
            self.initial_kernel_2 = self.add_weight(shape=(1, self.channels),
                                                    initializer=self.kernel_initializer,
                                                    name='initial_weight_kernel_2',
                                                    regularizer=self.kernel_regularizer,
                                                    constraint=self.kernel_constraint)
            self.initial_kernel_3 = self.add_weight(shape=(1, self.channels),
                                                    initializer=self.kernel_initializer,
                                                    name='initial_weight_kernel_3',
                                                    regularizer=self.kernel_regularizer,
                                                    constraint=self.kernel_constraint)
            self.initial_kernel_4 = self.add_weight(shape=(1, self.channels),
                                                    initializer=self.kernel_initializer,
                                                    name='initial_weight_kernel_4',
                                                    regularizer=self.kernel_regularizer,
                                                    constraint=self.kernel_constraint)
        else:
            self.initial_kernel = None


        self.lengthscale0_1 = self.add_weight(shape=(1,),
                                  initializer=RandomUniform(minval=0.1, maxval=2.),
                                  name='lengthscale0_1',
                                  regularizer=self.kernel_regularizer,
                                  constraint=min_max_norm(min_value=0.1, max_value=2.))
        self.lengthscale0_2 = self.add_weight(shape=(1,),
                                    initializer=RandomUniform(minval=0.1, maxval=2.),
                                    name='lengthscale0_2',
                                    regularizer=self.kernel_regularizer,
                                    constraint=min_max_norm(min_value=0.1, max_value=2.))
        self.lengthscale0_3 = self.add_weight(shape=(1,),
                                    initializer=RandomUniform(minval=0.1, maxval=2.),
                                    name='lengthscale0_3',
                                    regularizer=self.kernel_regularizer,
                                    constraint=min_max_norm(min_value=0.1, max_value=2.))
        self.lengthscale0_4 = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0.1, maxval=2.),
                                             name='lengthscale0_4',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0.1, max_value=2.))

        self.lengthscale1_1 = self.add_weight(shape=(1,),
                                              initializer=RandomUniform(minval=0.1, maxval=2.),
                                              name='lengthscale1_1',
                                              regularizer=self.kernel_regularizer,
                                              constraint=min_max_norm(min_value=0.1, max_value=2.))
        self.lengthscale1_2 = self.add_weight(shape=(1,),
                                              initializer=RandomUniform(minval=0.1, maxval=2.),
                                              name='lengthscale1_2',
                                              regularizer=self.kernel_regularizer,
                                              constraint=min_max_norm(min_value=0.1, max_value=2.))
        self.lengthscale1_3 = self.add_weight(shape=(1,),
                                              initializer=RandomUniform(minval=0.1, maxval=2.),
                                              name='lengthscale1_3',
                                              regularizer=self.kernel_regularizer,
                                              constraint=min_max_norm(min_value=0.1, max_value=2.))
        self.lengthscale1_4 = self.add_weight(shape=(1,),
                                              initializer=RandomUniform(minval=0.1, maxval=2.),
                                              name='lengthscale1_4',
                                              regularizer=self.kernel_regularizer,
                                              constraint=min_max_norm(min_value=0.1, max_value=2.))


        #----------------------------------------------------------------------------------------#
        self.period0_1 = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0.1, maxval=2),
                                             name='period0_1',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0.1, max_value=2))
        self.period0_2 = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0.1, maxval=2),
                                             name='period0_2',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0.1, max_value=2))
        self.period0_3 = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0.1, maxval=2),
                                             name='period0_3',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0.1, max_value=2))
        self.period0_4 = self.add_weight(shape=(1,),
                                             initializer=RandomUniform(minval=0.1, maxval=2),
                                             name='period0_4',
                                             regularizer=self.kernel_regularizer,
                                             constraint=min_max_norm(min_value=0.1, max_value=2))

        self.period1_1 = self.add_weight(shape=(1,),
                                        initializer=RandomUniform(minval=0.1, maxval=2),
                                        name='period1_1',
                                        regularizer=self.kernel_regularizer,
                                        constraint=min_max_norm(min_value=0.1, max_value=2))
        self.period1_2 = self.add_weight(shape=(1,),
                                        initializer=RandomUniform(minval=0.1, maxval=2),
                                        name='period1_2',
                                        regularizer=self.kernel_regularizer,
                                        constraint=min_max_norm(min_value=0.1, max_value=2))
        self.period1_3 = self.add_weight(shape=(1,),
                                        initializer=RandomUniform(minval=0.1, maxval=2),
                                        name='period1_3',
                                        regularizer=self.kernel_regularizer,
                                        constraint=min_max_norm(min_value=0.1, max_value=2))
        self.period1_4 = self.add_weight(shape=(1,),
                                        initializer=RandomUniform(minval=0.1, maxval=2),
                                        name='period1_4',
                                        regularizer=self.kernel_regularizer,
                                        constraint=min_max_norm(min_value=0.1, max_value=2))

        self.built = True

    def call(self, inputs):

        if inputs[0].shape[-1] == 2:
            # angle-1 #
            temp0_1 = tf.math.abs(inputs[0][:, :, :1] - self.kernel_mu0_1)
            temp0_1 = tf.multiply(temp0_1,tf.constant(m.pi))
            temp0_1 = tf.divide(temp0_1, self.period0_1)
            temp0_1 = tf.pow(tf.math.sin(temp0_1),2)
            temp0_1 = tf.multiply(tf.divide(temp0_1, self.lengthscale0_1), tf.constant(2., dtype=tf.float32))

            temp1_1 = tf.math.abs(inputs[0][:, :, 1:] - self.kernel_mu1_1)
            temp1_1 = tf.multiply(temp1_1, tf.constant(m.pi))
            temp1_1 = tf.divide(temp1_1, self.period1_1)
            temp1_1 = tf.pow(tf.math.sin(temp1_1), 2)
            temp1_1 = tf.multiply(tf.divide(temp1_1, self.lengthscale1_1), tf.constant(2., dtype=tf.float32))



            output_1 = tf.exp(-temp0_1 - temp1_1)
            output_1 = K.dot(output_1, self.initial_kernel_1)

            # angle-2 #
            temp0_2 = tf.math.abs(inputs[1][:, :, :1] - self.kernel_mu0_2)
            temp0_2 = tf.multiply(temp0_2, tf.constant(m.pi))
            temp0_2 = tf.divide(temp0_2, self.period0_2)
            temp0_2 = tf.pow(tf.math.sin(temp0_2), 2)
            temp0_2 = tf.multiply(tf.divide(temp0_2, self.lengthscale0_2), tf.constant(2., dtype=tf.float32))

            temp1_2 = tf.math.abs(inputs[1][:, :, 1:] - self.kernel_mu1_2)
            temp1_2 = tf.multiply(temp1_2, tf.constant(m.pi))
            temp1_2 = tf.divide(temp1_2, self.period1_2)
            temp1_2 = tf.pow(tf.math.sin(temp1_2), 2)
            temp1_2 = tf.multiply(tf.divide(temp1_2, self.lengthscale1_2), tf.constant(2., dtype=tf.float32))

            output_2 = tf.exp(-temp0_2 - temp1_2)
            output_2 = K.dot(output_2, self.initial_kernel_2)

            # angle-3 #
            temp0_3 = tf.math.abs(inputs[2][:, :, :1] - self.kernel_mu0_3)
            temp0_3 = tf.multiply(temp0_3, tf.constant(m.pi))
            temp0_3 = tf.divide(temp0_3, self.period0_3)
            temp0_3 = tf.pow(tf.math.sin(temp0_3), 2)
            temp0_3 = tf.multiply(tf.divide(temp0_3, self.lengthscale0_3), tf.constant(2., dtype=tf.float32))

            temp1_3 = tf.math.abs(inputs[2][:, :, 1:] - self.kernel_mu1_3)
            temp1_3 = tf.multiply(temp1_3, tf.constant(m.pi))
            temp1_3 = tf.divide(temp1_3, self.period1_3)
            temp1_3 = tf.pow(tf.math.sin(temp1_3), 2)
            temp1_3 = tf.multiply(tf.divide(temp1_3, self.lengthscale1_3), tf.constant(2., dtype=tf.float32))

            output_3 = tf.exp(-temp0_3 - temp1_3)
            output_3 = K.dot(output_3, self.initial_kernel_3)

            # angle-4 #
            temp0_4 = tf.math.abs(inputs[3][:, :, :1] - self.kernel_mu0_4)
            temp0_4 = tf.multiply(temp0_4, tf.constant(m.pi))
            temp0_4 = tf.divide(temp0_4, self.period0_4)
            temp0_4 = tf.pow(tf.math.sin(temp0_4), 2)
            temp0_4 = tf.multiply(tf.divide(temp0_4, self.lengthscale0_4), tf.constant(2., dtype=tf.float32))

            temp1_4 = tf.math.abs(inputs[3][:, :, 1:] - self.kernel_mu1_4)
            temp1_4 = tf.multiply(temp1_4, tf.constant(m.pi))
            temp1_4 = tf.divide(temp1_4, self.period1_4)
            temp1_4 = tf.pow(tf.math.sin(temp1_4), 2)
            temp1_4 = tf.multiply(tf.divide(temp1_4, self.lengthscale1_4), tf.constant(2., dtype=tf.float32))

            output_4 = tf.exp(-temp0_4 - temp1_4)
            output_4 = K.dot(output_4, self.initial_kernel_4)

            # this line is for kernel #
            output = tf.concat([output_1, output_2, output_3,output_4], axis=-1)
            output = K.expand_dims(output, axis=-1)
            output = MaxPooling2D(pool_size=(1, 4), padding='same')(output)
            output = tf.nn.elu(output)

        else:
            inputs = K.squeeze(inputs, axis=-1)
            output = K.dot(inputs, self.deep_kernel)
            output = tf.nn.elu(output)  # elu is optimal
            output = K.expand_dims(output, axis=-1)

        return output

    def compute_output_shape(self, input_shape):
        if len(input_shape) == 4:
            output_shape = input_shape[0][:-1] + (self.channels,) + (1,)
        else:
            output_shape = input_shape[:-2] + (self.channels,) + (1,)
        return output_shape

    def get_config(self):
        config = {
            'initial_kernel': self.initial_kernel,
            'channels': self.channels,
            'activation': activations.serialize(self.activation),
            'kernel_initializer': initializers.serialize(self.kernel_initializer),
            'kernel_regularizer': regularizers.serialize(self.kernel_regularizer),
            'activity_regularizer': regularizers.serialize(self.activity_regularizer),
            'kernel_constraint': constraints.serialize(self.kernel_constraint),
        }
        base_config = super(nOCTPERIODIC, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))


# attention mechanism #
# authors: since for mutag/PTC classification, the number of persistent pairs in PDs is very small,\
# in this case, we only assign random weights (from uniform distribution); you can find more PDs weight\
# application from our Github link

# PD's weight can be calcualted as follows #
def function_weight(name_weight, arc_c=1.0, arc_p=5.0, lin_el=1.0, power_k  = 2.0):
    if name_weight == "arctan":
        def func_weight(pd):
            return np.maximum(
                np.arctan(math.pow((pd[1] - pd[0]) / arc_c, arc_p)), power_k)
    elif name_weight == "linear":
        def func_weight(pd):
            return np.maximum(np.minimum((pd[1] - pd[0]) / lin_el, 1.0), power_k)
    else:  # unweighted
        def func_weight(pd):
            return 1.0
    return func_weight

class attention_mechanism(Layer):

    def __init__(self,
                 channels,
                 activation=None,
                 deep_kernel=None,
                 kernel_initializer='glorot_uniform',
                 kernel_regularizer=None,
                 activity_regularizer=None,
                 kernel_constraint=None,
                 **kwargs):
        if 'input_shape' not in kwargs and 'input_dim' in kwargs:
            kwargs['input_shape'] = (kwargs.pop('input_dim'),)
        super(attention_mechanism, self).__init__(**kwargs)
        self.deep_kernel = deep_kernel
        self.channels = channels
        self.activation = activations.get(activation)
        self.kernel_initializer = initializers.get(kernel_initializer)
        self.kernel_regularizer = regularizers.get(kernel_regularizer)
        self.activity_regularizer = regularizers.get(activity_regularizer)
        self.kernel_constraint = constraints.get(kernel_constraint)
        self.supports_masking = False

    def build(self, input_shape):
        self.deep_kernel = self.add_weight(shape=(int(len(input_shape)*input_shape[0][-2]), self.channels),
                                               initializer=self.kernel_initializer,
                                               name='deep_weight_kernel',
                                               regularizer=self.kernel_regularizer,
                                               constraint=self.kernel_constraint)

        self.alpha_1 = self.add_weight(shape=(1,),
                                  initializer=RandomUniform(minval=0.001, maxval=1.),
                                  name='alpha_at_1',
                                  regularizer=self.kernel_regularizer,
                                  constraint=min_max_norm(min_value=0.001, max_value=1.))
        self.alpha_2 = self.add_weight(shape=(1,),
                                    initializer=RandomUniform(minval=0.001, maxval=1.),
                                    name='alpha_at_2',
                                    regularizer=self.kernel_regularizer,
                                    constraint=min_max_norm(min_value=0.001, max_value=1))
        self.alpha_3 = self.add_weight(shape=(1,),
                                    initializer=RandomUniform(minval=0.001, maxval=1.),
                                    name='alpha_at_3',
                                    regularizer=self.kernel_regularizer,
                                    constraint=min_max_norm(min_value=0.001, max_value=1.))
        self.alpha_4 = self.add_weight(shape=(1,),
                                       initializer=RandomUniform(minval=0.001, maxval=1.),
                                       name='alpha_at_4',
                                       regularizer=self.kernel_regularizer,
                                       constraint=min_max_norm(min_value=0.001, max_value=1.))
        self.alpha_5 = self.add_weight(shape=(1,),
                                       initializer=RandomUniform(minval=0.001, maxval=1.),
                                       name='alpha_at_5',
                                       regularizer=self.kernel_regularizer,
                                       constraint=min_max_norm(min_value=0.001, max_value=1.))
        self.alpha_6 = self.add_weight(shape=(1,),
                                       initializer=RandomUniform(minval=0.001, maxval=1.),
                                       name='alpha_at_6',
                                       regularizer=self.kernel_regularizer,
                                       constraint=min_max_norm(min_value=0.001, max_value=1.))
        self.alpha_7 = self.add_weight(shape=(1,),
                                       initializer=RandomUniform(minval=0.001, maxval=1.),
                                       name='alpha_at_7',
                                       regularizer=self.kernel_regularizer,
                                       constraint=min_max_norm(min_value=0.001, max_value=1.))

        self.built = True

    def call(self, inputs):
        alpha_sum = tf.math.exp(self.alpha_1) + tf.math.exp(self.alpha_2) + tf.math.exp(self.alpha_3) + tf.math.exp(self.alpha_4)+ tf.math.exp(self.alpha_5) + tf.math.exp(self.alpha_6)+ tf.math.exp(self.alpha_7)
        soft_alpha_1 = tf.divide(tf.math.exp(self.alpha_1),alpha_sum)
        soft_alpha_2 = tf.divide(tf.math.exp(self.alpha_2), alpha_sum)
        soft_alpha_3 = tf.divide(tf.math.exp(self.alpha_3), alpha_sum)
        soft_alpha_4 = tf.divide(tf.math.exp(self.alpha_4), alpha_sum)
        soft_alpha_5 = tf.divide(tf.math.exp(self.alpha_5), alpha_sum)
        soft_alpha_6 = tf.divide(tf.math.exp(self.alpha_6), alpha_sum)
        soft_alpha_7 = tf.divide(tf.math.exp(self.alpha_6), alpha_sum)

        input_1 = tf.multiply(K.squeeze(inputs[0], axis=-1), soft_alpha_1)
        input_2 = tf.multiply(K.squeeze(inputs[1], axis=-1), soft_alpha_2)
        input_3 = tf.multiply(K.squeeze(inputs[2], axis=-1), soft_alpha_3)
        input_4 = tf.multiply(K.squeeze(inputs[3], axis=-1), soft_alpha_4)
        input_5 = tf.multiply(K.squeeze(inputs[4], axis=-1), soft_alpha_5)
        input_6 = tf.multiply(K.squeeze(inputs[5], axis=-1), soft_alpha_6)
        input_7 = tf.multiply(K.squeeze(inputs[6], axis=-1), soft_alpha_7)
        new_inputs = Concatenate(axis=-2)([K.expand_dims(input_1, axis=-1), K.expand_dims(input_2, axis=-1), K.expand_dims(input_3, axis=-1),
                                           K.expand_dims(input_4, axis=-1),K.expand_dims(input_5, axis=-1),K.expand_dims(input_6, axis=-1),K.expand_dims(input_7, axis=-1)])
        new_inputs = K.squeeze(new_inputs, axis=-1)
        output = K.dot(new_inputs, self.deep_kernel)
        output = tf.nn.elu(output)  # elu is optimal
        output = K.expand_dims(output, axis=-1)

        return output

    def compute_output_shape(self, input_shape):
        output_shape = input_shape[0][:-2] + (self.channels,) + (1,)
        return output_shape

    def get_config(self):
        config = {
            'initial_kernel': self.initial_kernel,
            'deep_kernel': self.deep_kernel,
            'channels': self.channels,
            'activation': activations.serialize(self.activation),
            'kernel_initializer': initializers.serialize(self.kernel_initializer),
            'kernel_regularizer': regularizers.serialize(self.kernel_regularizer),
            'activity_regularizer': regularizers.serialize(self.activity_regularizer),
            'kernel_constraint': constraints.serialize(self.kernel_constraint),
        }
        base_config = super(attention_mechanism, self).get_config()
        return dict(list(base_config.items()) + list(config.items()))