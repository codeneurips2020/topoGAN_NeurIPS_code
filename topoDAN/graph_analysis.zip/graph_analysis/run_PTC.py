import os
import networkx as nx
from scipy.sparse import csgraph, csr_matrix
from scipy.io import loadmat
from scipy.linalg import eigh
import numpy as np
from sklearn.metrics import pairwise_distances
import random
import tensorflow as tf
import keras
from keras import optimizers
from keras.utils import to_categorical
from keras.layers import Concatenate, Input, Dense, Flatten, Dropout, Conv2D, MaxPooling2D, Activation, concatenate, Reshape, AveragePooling1D, MaxPooling1D, Conv1D, ZeroPadding2D
from keras.models import Model
from keras.callbacks import ModelCheckpoint
from keras.regularizers import l2
import scipy.sparse as sp
from ExponentialTransformation import nOCTExponentialtransformation, nOCTPERIODIC, attention_mechanism
from keras.callbacks import EarlyStopping

# here we use the optimal PDs from HKS and optimal rotation angles #
# we extract PDs from HKS from "HKS_PDs_generation" folder #
# for various convolutional layers, you can find it in ExponentialTransformation.py #

current_path = os.getcwd()
dgms_path = current_path + '/PTC_TDA'
PTC_pd_1 = np.load(dgms_path +'/ten_LDgm_PDs.npy', allow_pickle= True)
PTC_pd_2 = np.load(dgms_path +'/two_ten_LDgm_PDs.npy', allow_pickle= True)
PTC_pd_3 = np.load(dgms_path +'/ten_LDgm_PDs.npy', allow_pickle= True)
labels = np.load(dgms_path +'/labels.npy')
num_pairs = 2

# PTC's PDs #
PDs_comb_1 = PTC_pd_1
PDs_comb_2 = PTC_pd_2
PDs_comb_3 = PTC_pd_3

PDs1_45 = []
PDs2_45 = []
PDs3_45 = []
PDs1_90 = []
PDs2_90 = []
PDs3_90 = []
PDs1_30 = []
PDs2_30 = []
PDs3_30 = []
PDs1_60 = []
PDs2_60 = []
PDs3_60 = []

for i in range(344):
    first_tmp = PDs_comb_1[i]
    second_tmp = PDs_comb_2[i]
    third_tmp = PDs_comb_3[i]

    copy_first_tmp = first_tmp
    copy_first_tmp[:, 1] = first_tmp[:, 1] - first_tmp[:, 0]
    longest_first_tmp = first_tmp[copy_first_tmp[:, 1].argsort()[-num_pairs:], :]
    # 45 #
    rotate_45 = np.array([np.cos(np.pi / 4), np.sin(np.pi / 4), -np.sin(np.pi / 4), np.cos(np.pi / 4)]).reshape((2, 2))
    longest_first_tmp_45 = np.dot(longest_first_tmp, rotate_45)
    # 90 #
    rotate_90 = np.array([np.cos(np.pi / 2), np.sin(np.pi / 2), -np.sin(np.pi / 2), np.cos(np.pi / 2)]).reshape((2, 2))
    longest_first_tmp_90 = np.dot(longest_first_tmp, rotate_90)
    # 30 #
    rotate_30 = np.array([np.cos(np.pi / 6), np.sin(np.pi / 6), -np.sin(np.pi / 6), np.cos(np.pi / 6)]).reshape((2, 2))
    longest_first_tmp_30 = np.dot(longest_first_tmp, rotate_30)
    # 60 #
    rotate_60 = np.array([np.cos(np.pi / 3), np.sin(np.pi / 3), -np.sin(np.pi / 3), np.cos(np.pi / 3)]).reshape((2, 2))
    longest_first_tmp_60 = np.dot(longest_first_tmp, rotate_60)

    copy_second_tmp = second_tmp
    copy_second_tmp[:, 1] = second_tmp[:, 1] - second_tmp[:, 0]
    longest_second_tmp = second_tmp[copy_second_tmp[:, 1].argsort()[-num_pairs:], :]
    # 45 #
    longest_second_tmp_45 = np.dot(longest_second_tmp, rotate_45)
    # 90 #
    longest_second_tmp_90 = np.dot(longest_second_tmp, rotate_90)
    # 30 #
    longest_second_tmp_30 = np.dot(longest_second_tmp, rotate_30)
    # 60 #
    longest_second_tmp_60 = np.dot(longest_second_tmp, rotate_60)

    copy_third_tmp = third_tmp
    copy_third_tmp[:, 1] = third_tmp[:, 1] - third_tmp[:, 0]
    longest_third_tmp = copy_third_tmp[copy_third_tmp[:, 1].argsort()[-num_pairs:], :]
    # 45 #
    longest_third_tmp_45 = np.dot(longest_third_tmp, rotate_45)
    # 90 #
    longest_third_tmp_90 = np.dot(longest_third_tmp, rotate_90)
    # 30 #
    longest_third_tmp_30 = np.dot(longest_third_tmp, rotate_30)
    # 60 #
    longest_third_tmp_60 = np.dot(longest_third_tmp, rotate_60)

    PDs1_45.append(np.abs(longest_first_tmp_45))
    PDs2_45.append(np.abs(longest_second_tmp_45))
    PDs3_45.append(np.abs(longest_third_tmp_45))

    PDs1_90.append(np.abs(longest_first_tmp_90))
    PDs2_90.append(np.abs(longest_second_tmp_90))
    PDs3_90.append(np.abs(longest_third_tmp_90))

    PDs1_30.append(np.abs(longest_first_tmp_30))
    PDs2_30.append(np.abs(longest_second_tmp_30))
    PDs3_30.append(np.abs(longest_third_tmp_30))

    PDs1_60.append(np.abs(longest_first_tmp_60))
    PDs2_60.append(np.abs(longest_second_tmp_60))
    PDs3_60.append(np.abs(longest_third_tmp_60))

input_PDs1_30 = np.asarray(PDs1_30)
input_PDs2_30 = np.asarray(PDs2_30)
input_PDs3_30 = np.asarray(PDs3_30)

input_PDs1_45 = np.asarray(PDs1_45)
input_PDs2_45 = np.asarray(PDs2_45)
input_PDs3_45 = np.asarray(PDs3_45)

input_PDs1_60 = np.asarray(PDs1_60)
input_PDs2_60 = np.asarray(PDs2_60)
input_PDs3_60 = np.asarray(PDs3_60)

input_PDs1_90 = np.asarray(PDs1_90)
input_PDs2_90 = np.asarray(PDs2_90)
input_PDs3_90 = np.asarray(PDs3_90)

index = np.arange(0,344)
random.shuffle(index)

# train
shuffle_input_PDs1_45_train = input_PDs1_45[index[0:round(344*0.9)],...]
shuffle_input_PDs2_45_train = input_PDs2_45[index[0:round(344*0.9)],...]
shuffle_input_PDs3_45_train = input_PDs3_45[index[0:round(344*0.9)],...]

shuffle_input_PDs1_90_train = input_PDs1_90[index[0:round(344*0.9)],...]
shuffle_input_PDs2_90_train = input_PDs2_90[index[0:round(344*0.9)],...]
shuffle_input_PDs3_90_train = input_PDs3_90[index[0:round(344*0.9)],...]

shuffle_input_PDs1_30_train = input_PDs1_30[index[0:round(344*0.9)],...]
shuffle_input_PDs2_30_train = input_PDs2_30[index[0:round(344*0.9)],...]
shuffle_input_PDs3_30_train = input_PDs3_30[index[0:round(344*0.9)],...]

shuffle_input_PDs1_60_train = input_PDs1_60[index[0:round(344*0.9)],...]
shuffle_input_PDs2_60_train = input_PDs2_60[index[0:round(344*0.9)],...]
shuffle_input_PDs3_60_train = input_PDs3_60[index[0:round(344*0.9)],...]

labels_train = labels[index[0:round(344*0.9)],...]

# test
shuffle_input_PDs1_45_test = input_PDs1_45[index[round(344*0.9):],...]
shuffle_input_PDs2_45_test = input_PDs2_45[index[round(344*0.9):],...]
shuffle_input_PDs3_45_test = input_PDs3_45[index[round(344*0.9):],...]

shuffle_input_PDs1_90_test = input_PDs1_90[index[round(344*0.9):],...]
shuffle_input_PDs2_90_test = input_PDs2_90[index[round(344*0.9):],...]
shuffle_input_PDs3_90_test = input_PDs3_90[index[round(344*0.9):],...]

shuffle_input_PDs1_30_test = input_PDs1_30[index[round(344*0.9):],...]
shuffle_input_PDs2_30_test = input_PDs2_30[index[round(344*0.9):],...]
shuffle_input_PDs3_30_test = input_PDs3_30[index[round(344*0.9):],...]

shuffle_input_PDs1_60_test = input_PDs1_60[index[round(344*0.9):],...]
shuffle_input_PDs2_60_test = input_PDs2_60[index[round(344*0.9):],...]
shuffle_input_PDs3_60_test = input_PDs3_60[index[round(344*0.9):],...]

labels_test = labels[index[round(344*0.9):],...]

num_classes = 2
learning_rate = 1e-3
l2_reg = 1e-4

def initial_rotation_PDs_layer(input_img):
    roate_layer = nOCTExponentialtransformation(64,
                       activation='elu',
                       regular_stretched = None,
                       kernel_regularizer=l2(l2_reg),
                       deep_kernel = None,
                       initial_kernel=True)(input_img)
    return roate_layer

def initial_hks_PDs_layer(input_img):
    hks_layer = nOCTPERIODIC(64,
                       activation='elu',
                       kernel_regularizer=l2(l2_reg),
                       initial_kernel=True)(input_img)
    return hks_layer


# model #
rotate_PD_input_45_1 = Input(shape=(num_pairs,2))
rotate_PD_input_45_2 = Input(shape=(num_pairs,2))
rotate_PD_input_45_3 = Input(shape=(num_pairs,2))
rotate_PD_input_90_1 = Input(shape=(num_pairs,2))
rotate_PD_input_90_2 = Input(shape=(num_pairs,2))
rotate_PD_input_90_3 = Input(shape=(num_pairs,2))
rotate_PD_input_30_1 = Input(shape=(num_pairs,2))
rotate_PD_input_30_2 = Input(shape=(num_pairs,2))
rotate_PD_input_30_3 = Input(shape=(num_pairs,2))
rotate_PD_input_60_1 = Input(shape=(num_pairs,2))
rotate_PD_input_60_2 = Input(shape=(num_pairs,2))
rotate_PD_input_60_3 = Input(shape=(num_pairs,2))

initial_rotate_PD_model_45 = initial_rotation_PDs_layer([rotate_PD_input_45_1,rotate_PD_input_45_2,rotate_PD_input_45_3])
initial_rotate_PD_model_90 = initial_rotation_PDs_layer([rotate_PD_input_90_1,rotate_PD_input_90_2,rotate_PD_input_90_3])
initial_rotate_PD_model_30 = initial_rotation_PDs_layer([rotate_PD_input_30_1,rotate_PD_input_30_2,rotate_PD_input_30_3])
initial_rotate_PD_model_60 = initial_rotation_PDs_layer([rotate_PD_input_60_1,rotate_PD_input_60_2,rotate_PD_input_60_3])
initial_hks_PD_model_1 = initial_hks_PDs_layer([rotate_PD_input_45_1,rotate_PD_input_90_1,rotate_PD_input_30_1,rotate_PD_input_60_1])
initial_hks_PD_model_2 = initial_hks_PDs_layer([rotate_PD_input_45_2,rotate_PD_input_90_2,rotate_PD_input_30_2,rotate_PD_input_60_2])
initial_hks_PD_model_3 = initial_hks_PDs_layer([rotate_PD_input_45_3,rotate_PD_input_90_3,rotate_PD_input_30_3,rotate_PD_input_60_3])

joint_model = attention_mechanism(64,
                                  activation='elu',
                                  kernel_regularizer=l2(l2_reg),
                                  deep_kernel=True)([initial_rotate_PD_model_45,initial_rotate_PD_model_90,initial_rotate_PD_model_30,initial_rotate_PD_model_60,
                                   initial_hks_PD_model_1,initial_hks_PD_model_2,initial_hks_PD_model_3])

joint_model = nOCTExponentialtransformation(64,
                                      activation='elu',
                                      regular_stretched = False,
                                      kernel_regularizer=l2(l2_reg),
                                      deep_kernel=True,
                                      initial_kernel=None)(joint_model)

conv = Flatten()(joint_model)
dense = Dense(512, activation='relu')(conv)
dense = Dropout(0.1)(dense)
output = Dense(num_classes, activation='softmax')(dense)

model = Model(inputs=[rotate_PD_input_45_1,rotate_PD_input_45_2,rotate_PD_input_45_3,
                      rotate_PD_input_90_1,rotate_PD_input_90_2,rotate_PD_input_90_3,
                      rotate_PD_input_30_1,rotate_PD_input_30_2,rotate_PD_input_30_3,
                      rotate_PD_input_60_1,rotate_PD_input_60_2,rotate_PD_input_60_3], outputs=[output])

opt = optimizers.Adam(lr = learning_rate)

model.compile(loss='categorical_crossentropy',
              optimizer=opt,
              metrics=['accuracy'])
model.summary()

model.fit([shuffle_input_PDs1_45_train, shuffle_input_PDs2_45_train,shuffle_input_PDs3_45_train,
           shuffle_input_PDs1_90_train, shuffle_input_PDs2_90_train,shuffle_input_PDs3_90_train,
           shuffle_input_PDs1_30_train, shuffle_input_PDs2_30_train,shuffle_input_PDs3_30_train,
           shuffle_input_PDs1_60_train, shuffle_input_PDs2_60_train,shuffle_input_PDs3_60_train], labels_train,
              batch_size=16,
              epochs=500,
              verbose=1,
              validation_data = ([shuffle_input_PDs1_45_test, shuffle_input_PDs2_45_test,shuffle_input_PDs3_45_test,
                                  shuffle_input_PDs1_90_test, shuffle_input_PDs2_90_test,shuffle_input_PDs3_90_test,
                                  shuffle_input_PDs1_30_test, shuffle_input_PDs2_30_test,shuffle_input_PDs3_30_test,
                                  shuffle_input_PDs1_60_test, shuffle_input_PDs2_60_test,shuffle_input_PDs3_60_test], labels_test),
              callbacks=[
              EarlyStopping(patience=200,  restore_best_weights=True)
          ])

final_loss, final_acc = model.evaluate([shuffle_input_PDs1_45_test, shuffle_input_PDs2_45_test,shuffle_input_PDs3_45_test,
                                  shuffle_input_PDs1_90_test, shuffle_input_PDs2_90_test,shuffle_input_PDs3_90_test,
                                  shuffle_input_PDs1_30_test, shuffle_input_PDs2_30_test,shuffle_input_PDs3_30_test,
                                  shuffle_input_PDs1_60_test, shuffle_input_PDs2_60_test,shuffle_input_PDs3_60_test], labels_test, verbose=1, batch_size = 1)
print("Final loss: {0:.6f}, final accuracy: {1:.6f}".format(final_loss, final_acc))
layer_names = [layer.name for layer in model.layers]
print(model.get_layer('attention_mechanism_1').get_weights())
