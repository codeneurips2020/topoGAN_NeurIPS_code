import os
import networkx as nx
from scipy.sparse import csgraph, csr_matrix
import numpy as np

def union_loss_categorical_crossentropy(preds, labels, PDs):
    argmax_row_num = np.argmax(preds)
    dis_sum = 0.
    for i in range(2):
        i_label = np.where(argmax_row_num == i)[0]
        dis_sum = dis_sum + np.sum(PDs[np.ix_(i_label,i_label)])

    return np.mean(-np.log(np.extract(labels, preds)))+dis_sum*0.1 # 0.1 is \lambda, i.e., hyperparameter for topo_loss function

def accuracy(preds, labels):
    return np.mean(np.equal(np.argmax(labels, 1), np.argmax(preds, 1)))

def evaluate_preds(preds, labels, PDs):

    split_loss = list()
    split_acc = list()

    split_loss.append(union_loss_categorical_crossentropy(preds, labels, PDs))
    split_acc.append(accuracy(preds, labels))

    return split_loss, split_acc