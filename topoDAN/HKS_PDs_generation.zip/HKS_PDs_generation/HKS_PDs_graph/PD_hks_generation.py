import networkx as nx
from scipy.sparse import csgraph, csr_matrix
from scipy.io import loadmat
from scipy.linalg import eigh
import numpy as np
from sklearn.metrics import pairwise_distances
from utils import get_base_simplex, hks_signature, apply_graph_extended_persistence

PTC_graphs = np.load('sparse_PTC_MR_graphs.npy', allow_pickle= True)

def LDgm(A, hks_time):
    L = csgraph.laplacian(A, normed=True)
    egvals, egvectors = eigh(L)
    basesimplex = get_base_simplex(A)
    filtration_val = hks_signature(egvectors, egvals, time=hks_time)
    bnds = [0., 1., 0., 1.]
    dgmOrd0, dgmExt0, dgmRel1, dgmExt1 = apply_graph_extended_persistence(A, filtration_val, basesimplex)
    DD = np.array([[bnds[0], bnds[2]], [bnds[1], bnds[2]], [bnds[0], bnds[3]], [bnds[1], bnds[3]]])
    LDgm = np.vstack([dgmOrd0, dgmExt0, dgmExt1, dgmRel1, DD])
    return dgmOrd0, dgmExt0, dgmRel1, dgmExt1, LDgm

LDgm_PDs = []
for i in range(len(PTC_graphs)):
    tmp_A = PTC_graphs[i].toarray()
    tmp_dgmOrd0, tmp_dgmExt0, tmp_dgmRel1, tmp_dgmExt1, tmp_LDgm = LDgm(tmp_A, hks_time = 1.)
    LDgm_PDs.append(tmp_LDgm)

np.save('LDgm_PDs',LDgm_PDs)