import os
import networkx as nx
import numpy as np
from sklearn.preprocessing import OneHotEncoder


def read_graphs_txt(ds_name):
    pre = ""

    with open("data/" + pre + ds_name + "/" + ds_name + "_graph_indicator.txt", "r") as f:
        graph_indicator = [int(i) - 1 for i in list(f)]

    # Nodes
    num_graphs = max(graph_indicator)
    node_indices = []
    offset = []
    c = 0

    for i in range(num_graphs + 1):
        print(i)
        offset.append(c)
        c_i = graph_indicator.count(i)
        node_indices.append((c, c + c_i - 1))
        c += c_i

    graph_list = []
    vertex_list = []
    for i in node_indices:
        g = nx.Graph(directed=False)
        vertex_list_g = []
        for j in range(i[1] - i[0] + 1):
            vertex_list_g.append(g.add_node(j))

        graph_list.append(g)
        vertex_list.append(vertex_list_g)

    # Edges
    with open("data/" + pre + ds_name + "/" + ds_name + "_A.txt", "r") as f:
        edges = [i.split(',') for i in list(f)]

    edges = [(int(e[0].strip()) - 1, int(e[1].strip()) - 1) for e in edges]

    edge_indicator = []
    edge_list = []
    for e in edges:
        g_id = graph_indicator[e[0]]
        edge_indicator.append(g_id)
        g = graph_list[g_id]
        off = offset[g_id]

        # Avoid multigraph
        edge_list.append(g.add_edge(e[0] - off, e[1] - off))

    # Node labels
    if os.path.exists("data/" + pre + ds_name + "/" + ds_name + "_node_labels.txt"):
        with open("data/" + pre + ds_name + "/" + ds_name + "_node_labels.txt", "r") as f:
            node_labels = [int(i) for i in list(f)]

        i = 0
        for g in graph_list:
            for n in g.nodes():
                g.nodes[n]['label'] = node_labels[i] ##### error ##### #
                i += 1

    # Node Attributes
    if os.path.exists("data/" + pre + ds_name + "/" + ds_name + "_node_attributes.txt"):
        with open("data/" + pre + ds_name + "/" + ds_name + "_node_attributes.txt", "r") as f:
            node_attributes = [map(float, i.split(',')) for i in list(f)]

        i = 0
        for g in graph_list:
            for n in g.nodes():
                g.nodes[n]['attributes'] = list(node_attributes[i])
                i += 1

    # Classes
    with open("data/" + pre + ds_name + "/" + ds_name + "_graph_labels.txt", "r") as f:
        classes = [int(i) for i in list(f)]

    return graph_list, classes

def nx_to_adj(graphs):
    if isinstance(graphs, nx.Graph):
        graphs = [graphs]
    return np.array([nx.attr_sparse_matrix(g)[0].toarray() for g in graphs])

def get_graph_kernel_dataset(dataset_ID):
    print('Loading data')
    nx_graphs, y = read_graphs_txt(dataset_ID)

    # Preprocessing
    y = np.array(y)[..., None]
    y = OneHotEncoder(sparse=False, categories='auto').fit_transform(y)
    A = nx_to_adj(nx_graphs)

    return A, y
