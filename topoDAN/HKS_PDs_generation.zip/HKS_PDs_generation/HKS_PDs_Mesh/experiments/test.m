%addpath('C:\Users\Synergy\Box Sync\3D classification\SHREC2010_simplified');
%addpath('C:\Users\Synergy\Box Sync\3D classification\SH15NR_S');
addpath('\Users\iumar\Box Sync\Research\3D classification\Shrec2014\Synthetic_5k\Data');

DATASET = 'SHREC2010_Nonrigid';  % dataset to process
max_num_evecs=200;
dtype = 'cotangent'; % distance type; can be 'cotangent', 'euclidean', 'geodesic'
DescriptorType = 'HKS'; % 'HKS','SIHKS' 'WKS'

%AssignmentType = 'Soft'; 
%DESCRIPTOR_NORMALIZATION = 'L2'; % Can be 'none', 'L1' or 'L2'
%SIGMA_SCALE = 2; 

%load('index.csv');

for i = 0:299 %0:1199 for Shrec2015
    
    %file=strcat('T',int2str(i),'.off');
    file=strcat(int2str(i),'.off');
    
    % read .off file
    [vertices,faces]=read_off(file);

    % mesh to shape
    shape=mesh2shape(vertices,faces);    
   
    % Compute e-vectors and e-values  
    num_vert = length(shape.X);
    num_evecs = min(num_vert - 1, max_num_evecs);    
    [evecs, evals, W, A] = main_mshlp(dtype, shape, num_evecs);

    % Compute spectral descriptors
    desc = Get_Signature(evecs, evals,DescriptorType,DATASET);
    %desc = normalize(desc, DESCRIPTOR_NORMALIZATION, 2);
    
    %show one component of HKS and SI-HKS at all points
    %figure(i+1)
    %subplot(1,2,1)
    %hold on
    %trisurf(shape.TRIV,shape.X,shape.Y,shape.Z, desc(:,5)), axis image, shading interp, 
    %view([90 270]),
    %title('HKS')
    %axis off
    
    % write desc into csv file
    destn=strcat(DescriptorType,'_Shrec2014_Real_5k\T',int2str(i),'.csv');
    csvwrite(destn,desc);

end

